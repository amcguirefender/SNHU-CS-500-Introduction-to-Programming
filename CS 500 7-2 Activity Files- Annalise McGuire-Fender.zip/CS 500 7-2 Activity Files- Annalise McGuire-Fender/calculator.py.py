print("Hello, welcome to your calculator.")

yes = 1 #arbitrary value used to begin the while loop and prompt the calculation menu (see lines 93-98 for reiteration of the while loop)

while yes == 1: #while loop to keep prompting the calculation menu and calculation inputs

    print("Please select one of the calculation types from the menu below:\nA: Addition\nB: Subtraction\nC: Division\nD: Multiplication")

    calculation_type = str(input())

#Addition calculation
    if calculation_type in ['a', 'A']:
        print("Please enter the two numbers that you want to add together (Example: A + B)")
        while True:
            try:
                number_1_input = input("Number A (maximum of 10 digits): ")
                number_2_input = input("Number B (maximum of 10 digits): ")
                if len(number_1_input) > 10 or len(number_2_input) > 10:
                    print("I'm sorry but the numbers you have entered exceed the 10 digit limit, please try again.\n")
                    continue
                number_1 = float(number_1_input)
                number_2 = float(number_2_input)
                addition_output = number_1 + number_2
                print(f"Okay, {number_1:,.2f} + {number_2:,.2f} = {addition_output:,.2f}")
                break
            except ValueError:
                print("I'm sorry it looks like the characters you entered were not both numbers, please try again") 
        
#Subtraction calculation
    elif calculation_type in ['b', 'B']:
        print("Please enter the two numbers that you want to subtracted (Example: A - B)")
        while True:
            try:
                number_1_input = input("Number A (maximum of 10 digits): ")
                number_2_input = input("Number B (maximum of 10 digits): ")
                if len(number_1_input) > 10 or len(number_2_input) > 10:
                    print("I'm sorry but the numbers you have entered exceed the 10 digit limit, please try again.\n")
                    continue
                number_1 = float(number_1_input)
                number_2 = float(number_2_input)
                subtraction_output = number_1 - number_2
                print(f"Okay, {number_1:,.2f} - {number_2:,.2f} = {subtraction_output:,.2f}")
                break
            except ValueError:
                print("I'm sorry it looks like the characters you entered were not both numbers, please try again") 
        
#Division calculation
    elif calculation_type in ['c', 'C']:
        print("Please enter the two numbers that you want to add divided (Example: A / B)")
        while True:
            try:
                number_1_input = input("Number A (maximum of 10 digits): ")
                number_2_input = input("Number B (maximum of 10 digits): ")
                if len(number_1_input) > 10 or len(number_2_input) > 10:
                    print("I'm sorry but the numbers you have entered exceed the 10 digit limit, please try again.\n")
                    continue
                number_1 = float(number_1_input)
                number_2 = float(number_2_input)
                division_output = number_1 / number_2
                break
            except ValueError:
                print("I'm sorry it looks like the characters you entered were not both numbers, please try again") 
            except ZeroDivisionError:
                print("I'm sorry it looks like you are trying to divide by zero, please try again")
        
        print(f"Okay, {number_1:,.2f} / {number_2:,.2f} = {division_output:,.2f}")

#Multiplication calculation
    elif calculation_type in ['d', 'D']:
        print("Please enter the two numbers that you want to add multiplied (Example: A * B)")
        while True:
            try:
                number_1_input = input("Number A (maximum of 6 digits): ")
                number_2_input = input("Number B (maximum of 6 digits): ")
                if len(number_1_input) > 6 or len(number_2_input) > 6:
                    print("I'm sorry but the numbers you have entered exceed the 6 digit limit, please try again.\n")
                    continue
                number_1 = float(number_1_input)
                number_2 = float(number_2_input) 
                multiplication_output = number_1 * number_2
                print(f"Okay, {number_1:,.2f} * {number_2:,.2f} = {multiplication_output:,.2f}")
                break
            except ValueError:
                print("I'm sorry it looks like the characters you entered were not both numbers, please try again") 
        

    else:
        print("I'm sorry but the option you have entered in not valid. Please try again")

    print("Would you like to run another calculation?")
    another_calculation = str(input())

#Ensures that user keeps returning to the calculation menu if they respond yes, if not the program is terminated
    if another_calculation in ["y", "Y", "Yes", "YES"]:
            yes = 1
    else: 
            yes = 0
            print("Okay, goodbye.")

# Unit tests to check the accuracy of the arithmetic operations
import unittest

class ArithmeticOperationsTests(unittest.TestCase):
  
    def addition(self, A, B): 
        return (A + B)
        
    def subtraction(self, A, B): 
        return (A - B)
        
    def division(self, A, B): 
        return (A / B)
        
    def multiplication(self, A, B): 
        return (A * B)
        
    def test_addition(self):
        result = self.addition(2, 2)
        self.assertEqual(result, 4)
        
    def test_subtraction(self):
        result = self.subtraction(5, 2)
        self.assertEqual(result, 3)
        
    def test_division(self):
        result = self.division(5, 2)
        self.assertEqual(result, 2.50)

    def test_division_by_zero(self):
         with self.assertRaises(ZeroDivisionError):
            self.division(5, 0)
        
    def test_multiplication(self):
        result = self.multiplication(4, 4)
        self.assertEqual(result, 16)

    def test_addition_non_numbers(self):
        p = "word"
        with self.assertRaises(TypeError):
            self.addition(p, 5)

if __name__ == '__main__':
    unittest.main()

